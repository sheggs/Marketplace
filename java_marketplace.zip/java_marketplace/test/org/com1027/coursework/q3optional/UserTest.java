package org.com1027.coursework.q3optional;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Tests for the User class.
 *
 * @author Stella Kazamia
 */
public class UserTest {

  /**
   * Creating a User object with valid input parameter for the user. Test that the toString() can be retrieved correctly.
   *
   *
   */
  @Test
  public void testUserConstruction() {
    User user = new User("Helen");
    assertEquals("H***n", user.toString());
  }
  /**
   * Creating a user object and testing if the displayBids function correctly works.
   */
  @Test
  public void testUserDisplayBids() {
    User user = new User("Josh");
    user.wonAuction(2, 8.00);
    user.wonAuction(3, 14.00);
    assertEquals("Successful Bids: \n" + "2 at a cost of 8.0\n" + "3 at a cost of 14.0\n" + "", user.displaySuccessfulBids());

  }

  /**
   * Creating a user object and testing if the displayPurchases function correctly works.
   */
  @Test
  public void testUserDisplayPurchases() {
    User user = new User("Hassan");
    user.buy(10, 300);
    user.buy(3, 9);
    // System.out.println(user.displayAllPurchases());
    assertEquals("Purchases: \n" + "3 with quantity 9\n" + "10 with quantity 300\n", user.displayPurchases());
  }

  /**
   * Creating a User object with invalid input parameter for the user. Test that the exception thrown.
   *
   *
   */
  @Test(expected = IllegalArgumentException.class)
  public void testUserInvalidConstructions() {
    new User(null);
  }
}
