package org.com1027.coursework.q1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class BidTest {

  /**
   * Creating an Bid object and checks if the Bid is correctly made.
   */
  @Test
  public void testBidConstruction() {
    User Joane = new User("Joane");
    Bid testBid = new Bid(Joane, 10);
    assertEquals(10, testBid.getBidValue(), 0);
    assertEquals("Joane", testBid.getBuyer().toString());
  }

  /* This creates a bid object with a bid value of 0. This should return an illegal Argument Exception */
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidBidValueConstruction() {
    new Bid(new User("Bobby"), 0);

  }

  /* This creates a bid object with a null user. This should return an illegal Argument Exception */
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidUserConstruction() {
    new Bid(null, 100);

  }

  /**
   * Testing if the toString() function works correctly.
   */
  @Test
  public void testToString() {
    Bid testBid = new Bid(new User("Johnny"), 30.00);
    System.out.println(testBid.toString());
    assertEquals("Johnny bid �30.0", testBid.toString());
  }

}
